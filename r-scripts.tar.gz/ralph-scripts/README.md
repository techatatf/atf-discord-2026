# ralph-scripts

Scripts for running coding agents against this repo.

## once.sh

Run a single agent session against the current repo state.

```bash
./ralph-scripts/once.sh <agent> <model-alias>
```

### Agents

| Agent    | Description                        |
|----------|------------------------------------|
| `pi`     | Pi coding agent                    |
| `claude` | Claude Code CLI                    |

### Model aliases

| Alias  | pi                                          | claude          |
|--------|---------------------------------------------|-----------------|
| `opus` | `anthropic/claude-opus-4.6`                 | `claude-opus-4-6` |
| `kimi` | `openrouter/kimi-k2.6` + `--thinking high` | ❌ not supported |

### Examples

```bash
./ralph-scripts/once.sh pi opus      # Pi with Opus
./ralph-scripts/once.sh pi kimi      # Pi with Kimi (thinking enabled)
./ralph-scripts/once.sh claude opus  # Claude Code with Opus
```

### Adding a new model

Add a `case` block under each agent in `once.sh`:

```bash
# Under the pi) case:
newmodel)
    model="provider/model-name"
    extra_flags=""  # or "--thinking high" etc.
    ;;

# Under the claude) case (or add an error if unsupported):
newmodel)
    model="model-name-for-claude"
    extra_flags=""
    ;;
```

Then update the usage message at the top of the script.

## Tests

```bash
bash ralph-scripts/once.test.sh
```
