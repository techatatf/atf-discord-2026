#!/bin/bash

# Usage: ./once.sh <agent> <model-alias>
# Agents: pi, claude
# Model aliases: opus, kimi

if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Usage: once.sh <agent> <model-alias>"
    echo "  Agents: pi, claude"
    echo "  Models: opus, kimi"
    exit 1
fi

agent="$1"
model_alias="$2"

# --- Resolve model alias to agent-specific flags ---

case "${agent}" in
    pi)
        case "${model_alias}" in
            opus)
                model="anthropic/claude-opus-4.6"
                extra_flags=""
                ;;
            kimi)
                model="openrouter/kimi-k2.6"
                extra_flags="--thinking high"
                ;;
            *)
                echo "Error: unknown model alias '${model_alias}'. Known: opus, kimi"
                exit 1
                ;;
        esac
        ;;
    claude)
        case "${model_alias}" in
            opus)
                model="claude-opus-4-6"
                extra_flags=""
                ;;
            kimi)
                echo "Error: '${model_alias}' is not supported with claude agent."
                exit 1
                ;;
            *)
                echo "Error: unknown model alias '${model_alias}'. Known: opus"
                exit 1
                ;;
        esac
        ;;
    *)
        echo "Error: unknown agent '${agent}'. Known: pi, claude"
        exit 1
        ;;
esac

# --- Build context ---

issues=$(cat docs/issues/*.md 2>/dev/null || echo "No issues found")
commits=$(git log -n 5 --format="%H%n%ad%n%B---" --date=short 2>/dev/null || echo "No commits found")
prompt=$(cat ralph-scripts/prompt.md)

# --- Run ---

PI_CMD="${PI_CMD:-pi}"
CLAUDE_CMD="${CLAUDE_CMD:-claude}"

case "${agent}" in
    pi)
        ${PI_CMD} --model "${model}" ${extra_flags} \
            --skill ~/.agents/skills/tdd/SKILL.md \
            "Previous commits: ${commits} Issues: ${issues} ${prompt}"
        ;;
    claude)
        ${CLAUDE_CMD} --permission-mode acceptEdits \
            --model "${model}" ${extra_flags} \
            "Previous commits: ${commits} Issues: ${issues} ${prompt}"
        ;;
esac
