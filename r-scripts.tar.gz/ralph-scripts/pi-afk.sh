#!/bin/bash

# pi-afk.sh — Runs pi sessions in a loop until done or failure.
#
# Why require a max-iterations argument?
# Each iteration is an API call that costs real money and takes minutes.
# Without a cap, a stuck loop (pi keeps running but never finishes an issue)
# burns credits until you notice. The cap forces you to estimate how many
# iterations you expect, and stops the loop if something goes wrong.

# --- Configuration ---
PI_MODEL="openrouter/kimi-k2.6"
PI_THINKING="high"
PI_SKILL="$HOME/.agents/skills/tdd/SKILL.md"
PI_CMD="${PI_CMD:-pi}"  # Override with PI_CMD for testing

# --- Usage ---
if [ -z "$1" ]; then
    echo "Usage: ralph/pi-afk.sh <max-iterations>"
    echo ""
    echo "Runs pi sessions continuously until:"
    echo "  - All issues in docs/issues/ are resolved"
    echo "  - Pi outputs <promise>NO MORE TASKS</promise>"
    echo "  - Pi exits with a non-zero exit code (failure)"
    echo "  - Max iterations reached"
    echo ""
    echo "Why require max-iterations?"
    echo "  Each iteration is an API call that costs money and takes minutes."
    echo "  The cap prevents runaway loops when pi is stuck. Pick a number"
    echo "  a bit higher than your issue count (e.g., issues × 2)."
    exit 1
fi

max_iterations=$1
iteration=1

echo "Starting pi-afk session (max ${max_iterations} iterations)..."

while [ "${iteration}" -le "${max_iterations}" ]; do
    # Fast-path: no issues left
    total_issues=$(find docs/issues -maxdepth 1 -name "*.md" 2>/dev/null | wc -l)
    if [ "${total_issues}" -eq 0 ]; then
        echo "No more issues in docs/issues/. pi-afk complete."
        exit 0
    fi

    echo "=== Iteration ${iteration}/${max_iterations} ==="
    echo "Found ${total_issues} remaining issue(s)"

    # Collect context
    commits=$(git log -n 5 --format="%H%n%ad%n%B---" --date=short 2>/dev/null || echo "No commits found")
    issues=$(cat docs/issues/*.md 2>/dev/null || echo "No issues found")
    prompt=$(cat ralph/prompt.md 2>/dev/null || echo "No prompt found")

    # Run pi, capture output to temp file for signal detection
    session_output=$(mktemp)
    trap "rm -f ${session_output}" EXIT

    ${PI_CMD} -p \
        --model "${PI_MODEL}" \
        --thinking "${PI_THINKING}" \
        --skill "${PI_SKILL}" \
        "Previous commits: ${commits} Issues: ${issues} ${prompt}" 2>&1 | tee "${session_output}"

    pi_exit=${PIPESTATUS[0]}

    # Check for failure
    if [ "${pi_exit}" -ne 0 ]; then
        echo "pi exited with code ${pi_exit} on iteration ${iteration}. Stopping."
        rm -f "${session_output}"
        exit 1
    fi

    # Check for completion signal
    if grep -q "<promise>NO MORE TASKS</promise>" "${session_output}"; then
        echo "NO MORE TASKS signal received. pi-afk complete after ${iteration} iteration(s)."
        rm -f "${session_output}"
        exit 0
    fi

    echo "Iteration ${iteration} complete, continuing..."
    rm -f "${session_output}"
    iteration=$((iteration + 1))
    sleep 1
done

echo "Reached max iterations (${max_iterations}). Stopping."
exit 1
