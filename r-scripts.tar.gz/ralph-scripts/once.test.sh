#!/bin/bash

# Integration tests for once.sh

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PASS=0
FAIL=0

assert_eq() {
    local label="$1" expected="$2" actual="$3"
    if [ "$expected" = "$actual" ]; then
        echo "  PASS: ${label}"
        PASS=$((PASS + 1))
    else
        echo "  FAIL: ${label} (expected '${expected}', got '${actual}')"
        FAIL=$((FAIL + 1))
    fi
}

assert_contains() {
    local label="$1" needle="$2" haystack="$3"
    if printf '%s\n' "${haystack}" | grep -qF -- "${needle}"; then
        echo "  PASS: ${label}"
        PASS=$((PASS + 1))
    else
        echo "  FAIL: ${label} (expected output to contain '${needle}')"
        FAIL=$((FAIL + 1))
    fi
}

setup_tmpdir() {
    TMPDIR=$(mktemp -d)
    mkdir -p "${TMPDIR}/ralph-scripts"
    mkdir -p "${TMPDIR}/docs/issues"
    cp "${SCRIPT_DIR}/once.sh" "${TMPDIR}/ralph-scripts/once.sh"
    echo "Do the work." > "${TMPDIR}/ralph-scripts/prompt.md"
    git -C "${TMPDIR}" init -q
    git -C "${TMPDIR}" config user.email "test@test.com"
    git -C "${TMPDIR}" config user.name "test"
    git -C "${TMPDIR}" add -A && git -C "${TMPDIR}" commit -q -m "init" --allow-empty
}

teardown_tmpdir() {
    rm -rf "${TMPDIR}"
}

# ============================================================
# Test 1: No args shows usage and exits 1
# ============================================================
echo "Test 1: no args shows usage"
setup_tmpdir

output=$(cd "${TMPDIR}" && bash ralph-scripts/once.sh 2>&1)
exit_code=$?

assert_eq "exit code is 1" "1" "${exit_code}"
assert_contains "shows usage" "Usage:" "${output}"

teardown_tmpdir

# ============================================================
# Test 2: One arg shows usage and exits 1
# ============================================================
echo "Test 2: one arg shows usage"
setup_tmpdir

output=$(cd "${TMPDIR}" && bash ralph-scripts/once.sh pi 2>&1)
exit_code=$?

assert_eq "exit code is 1" "1" "${exit_code}"
assert_contains "shows usage" "Usage:" "${output}"

teardown_tmpdir

# ============================================================
# Test 3: pi opus calls pi with correct model and skill
# ============================================================
echo "Test 3: pi opus"
setup_tmpdir

fake_pi="${TMPDIR}/fake-pi.sh"
cat > "${fake_pi}" << 'EOF'
#!/bin/bash
echo "CALLED: $@"
exit 0
EOF
chmod +x "${fake_pi}"

export PI_CMD="${fake_pi}"
output=$(cd "${TMPDIR}" && bash ralph-scripts/once.sh pi opus 2>&1)
exit_code=$?
unset PI_CMD

assert_eq "exit code is 0" "0" "${exit_code}"
assert_contains "uses correct model" "anthropic/claude-opus-4.6" "${output}"
assert_contains "passes skill flag" "--skill" "${output}"

teardown_tmpdir

# ============================================================
# Test 4: pi kimi calls pi with kimi model and --thinking high
# ============================================================
echo "Test 4: pi kimi"
setup_tmpdir

fake_pi="${TMPDIR}/fake-pi.sh"
cat > "${fake_pi}" << 'EOF'
#!/bin/bash
echo "CALLED: $@"
exit 0
EOF
chmod +x "${fake_pi}"

export PI_CMD="${fake_pi}"
output=$(cd "${TMPDIR}" && bash ralph-scripts/once.sh pi kimi 2>&1)
exit_code=$?
unset PI_CMD

assert_eq "exit code is 0" "0" "${exit_code}"
assert_contains "uses kimi model" "openrouter/kimi-k2.6" "${output}"
assert_contains "passes thinking flag" "--thinking high" "${output}"
assert_contains "passes skill flag" "--skill" "${output}"

teardown_tmpdir

# ============================================================
# Test 5: claude opus calls claude with correct model and permission mode
# ============================================================
echo "Test 5: claude opus"
setup_tmpdir

fake_claude="${TMPDIR}/fake-claude.sh"
cat > "${fake_claude}" << 'EOF'
#!/bin/bash
echo "CALLED: $@"
exit 0
EOF
chmod +x "${fake_claude}"

export CLAUDE_CMD="${fake_claude}"
output=$(cd "${TMPDIR}" && bash ralph-scripts/once.sh claude opus 2>&1)
exit_code=$?
unset CLAUDE_CMD

assert_eq "exit code is 0" "0" "${exit_code}"
assert_contains "uses claude model" "claude-opus-4-6" "${output}"
assert_contains "passes permission mode" "--permission-mode acceptEdits" "${output}"

teardown_tmpdir

# ============================================================
# Test 6: claude kimi errors
# ============================================================
echo "Test 6: claude kimi errors"
setup_tmpdir

output=$(cd "${TMPDIR}" && bash ralph-scripts/once.sh claude kimi 2>&1)
exit_code=$?

assert_eq "exit code is 1" "1" "${exit_code}"
assert_contains "says not supported" "not supported" "${output}"

teardown_tmpdir

# ============================================================
# Test 7: invalid agent errors
# ============================================================
echo "Test 7: invalid agent"
setup_tmpdir

output=$(cd "${TMPDIR}" && bash ralph-scripts/once.sh gemini opus 2>&1)
exit_code=$?

assert_eq "exit code is 1" "1" "${exit_code}"
assert_contains "says unknown agent" "unknown agent" "${output}"

teardown_tmpdir

# ============================================================
# Test 8: invalid model alias errors
# ============================================================
echo "Test 8: invalid model alias"
setup_tmpdir

output=$(cd "${TMPDIR}" && bash ralph-scripts/once.sh pi gpt5 2>&1)
exit_code=$?

assert_eq "exit code is 1" "1" "${exit_code}"
assert_contains "says unknown model" "unknown model alias" "${output}"

teardown_tmpdir

# ============================================================
echo ""
echo "Results: ${PASS} passed, ${FAIL} failed"
[ "${FAIL}" -eq 0 ] && exit 0 || exit 1
