#!/bin/bash

# Integration tests for pi-afk.sh
# Uses PI_CMD to inject fake pi commands and a temp dir to isolate filesystem state.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PASS=0
FAIL=0

setup_tmpdir() {
    TMPDIR=$(mktemp -d)
    mkdir -p "${TMPDIR}/docs/issues/done"
    mkdir -p "${TMPDIR}/ralph"
    cp "${SCRIPT_DIR}/pi-afk.sh" "${TMPDIR}/ralph/pi-afk.sh"
    echo "Pick a task." > "${TMPDIR}/ralph/prompt.md"
    # Init a git repo so git log doesn't fail
    git -C "${TMPDIR}" init -q
    git -C "${TMPDIR}" config user.email "test@test.com"
    git -C "${TMPDIR}" config user.name "test"
    git -C "${TMPDIR}" add -A && git -C "${TMPDIR}" commit -q -m "init" --allow-empty
}

teardown_tmpdir() {
    rm -rf "${TMPDIR}"
}

assert_eq() {
    local label="$1" expected="$2" actual="$3"
    if [ "$expected" = "$actual" ]; then
        echo "  PASS: ${label}"
        PASS=$((PASS + 1))
    else
        echo "  FAIL: ${label} (expected '${expected}', got '${actual}')"
        FAIL=$((FAIL + 1))
    fi
}

assert_contains() {
    local label="$1" needle="$2" haystack="$3"
    if echo "${haystack}" | grep -q "${needle}"; then
        echo "  PASS: ${label}"
        PASS=$((PASS + 1))
    else
        echo "  FAIL: ${label} (expected output to contain '${needle}')"
        FAIL=$((FAIL + 1))
    fi
}

# ============================================================
# Test 1: Missing argument shows usage and exits 1
# ============================================================
echo "Test 1: missing argument"
setup_tmpdir

output=$(cd "${TMPDIR}" && bash ralph/pi-afk.sh 2>&1)
exit_code=$?

assert_eq "exit code is 1" "1" "${exit_code}"
assert_contains "shows usage" "Usage:" "${output}"
assert_contains "explains why" "costs money" "${output}"

teardown_tmpdir

# ============================================================
# Test 2: No issues → exits 0 without calling pi
# ============================================================
echo "Test 2: no issues fast-path"
setup_tmpdir

# PI_CMD points to something that should NOT be called
export PI_CMD="false"
output=$(cd "${TMPDIR}" && bash ralph/pi-afk.sh 5 2>&1)
exit_code=$?
unset PI_CMD

assert_eq "exit code is 0" "0" "${exit_code}"
assert_contains "reports no issues" "No more issues" "${output}"

teardown_tmpdir

# ============================================================
# Test 3: Pi exits non-zero → stops with error
# ============================================================
echo "Test 3: pi failure stops loop"
setup_tmpdir

echo "# Issue" > "${TMPDIR}/docs/issues/01-test.md"

# Fake pi that fails
fake_pi="${TMPDIR}/fake-pi.sh"
cat > "${fake_pi}" << 'EOF'
#!/bin/bash
echo "API error: rate limited"
exit 1
EOF
chmod +x "${fake_pi}"

export PI_CMD="${fake_pi}"
output=$(cd "${TMPDIR}" && bash ralph/pi-afk.sh 5 2>&1)
exit_code=$?
unset PI_CMD

assert_eq "exit code is 1" "1" "${exit_code}"
assert_contains "reports failure" "exited with code 1" "${output}"

teardown_tmpdir

# ============================================================
# Test 4: Pi outputs NO MORE TASKS → stops with success
# ============================================================
echo "Test 4: completion signal"
setup_tmpdir

echo "# Issue" > "${TMPDIR}/docs/issues/01-test.md"

fake_pi="${TMPDIR}/fake-pi.sh"
cat > "${fake_pi}" << 'EOF'
#!/bin/bash
echo "All done."
echo "<promise>NO MORE TASKS</promise>"
exit 0
EOF
chmod +x "${fake_pi}"

export PI_CMD="${fake_pi}"
output=$(cd "${TMPDIR}" && bash ralph/pi-afk.sh 5 2>&1)
exit_code=$?
unset PI_CMD

assert_eq "exit code is 0" "0" "${exit_code}"
assert_contains "reports completion" "NO MORE TASKS signal received" "${output}"
assert_contains "shows iteration count" "1 iteration(s)" "${output}"

teardown_tmpdir

# ============================================================
# Test 5: Max iterations reached → stops
# ============================================================
echo "Test 5: max iterations"
setup_tmpdir

echo "# Issue" > "${TMPDIR}/docs/issues/01-test.md"

# Fake pi that succeeds but never signals completion
fake_pi="${TMPDIR}/fake-pi.sh"
cat > "${fake_pi}" << 'EOF'
#!/bin/bash
echo "Made some progress"
exit 0
EOF
chmod +x "${fake_pi}"

export PI_CMD="${fake_pi}"
output=$(cd "${TMPDIR}" && bash ralph/pi-afk.sh 3 2>&1)
exit_code=$?
unset PI_CMD

assert_eq "exit code is 1" "1" "${exit_code}"
assert_contains "reports max reached" "Reached max iterations (3)" "${output}"

teardown_tmpdir

# ============================================================
# Test 6: Loop continues across iterations until signal
# ============================================================
echo "Test 6: multi-iteration loop"
setup_tmpdir

echo "# Issue" > "${TMPDIR}/docs/issues/01-test.md"

# Fake pi that signals completion on 3rd call
fake_pi="${TMPDIR}/fake-pi.sh"
counter="${TMPDIR}/counter"
echo "0" > "${counter}"
cat > "${fake_pi}" << EOF
#!/bin/bash
count=\$(cat "${counter}")
count=\$((count + 1))
echo "\${count}" > "${counter}"
if [ "\${count}" -eq 3 ]; then
    echo "<promise>NO MORE TASKS</promise>"
else
    echo "Working on iteration \${count}"
fi
exit 0
EOF
chmod +x "${fake_pi}"

export PI_CMD="${fake_pi}"
output=$(cd "${TMPDIR}" && bash ralph/pi-afk.sh 10 2>&1)
exit_code=$?
unset PI_CMD

assert_eq "exit code is 0" "0" "${exit_code}"
assert_contains "ran iteration 1" "Iteration 1/10" "${output}"
assert_contains "ran iteration 2" "Iteration 2/10" "${output}"
assert_contains "ran iteration 3" "Iteration 3/10" "${output}"
assert_contains "stopped at 3" "3 iteration(s)" "${output}"

teardown_tmpdir

# ============================================================
# Test 7: Loop stops early when issues disappear between iterations
# ============================================================
echo "Test 7: issues removed mid-loop"
setup_tmpdir

echo "# Issue" > "${TMPDIR}/docs/issues/01-test.md"

# Fake pi that removes the issue on first call
fake_pi="${TMPDIR}/fake-pi.sh"
cat > "${fake_pi}" << EOF
#!/bin/bash
rm -f "${TMPDIR}/docs/issues/01-test.md"
echo "Completed issue, moved to done"
exit 0
EOF
chmod +x "${fake_pi}"

export PI_CMD="${fake_pi}"
output=$(cd "${TMPDIR}" && bash ralph/pi-afk.sh 10 2>&1)
exit_code=$?
unset PI_CMD

assert_eq "exit code is 0" "0" "${exit_code}"
assert_contains "ran iteration 1" "Iteration 1/10" "${output}"
assert_contains "stopped on no issues" "No more issues" "${output}"

teardown_tmpdir

# ============================================================
echo ""
echo "Results: ${PASS} passed, ${FAIL} failed"
[ "${FAIL}" -eq 0 ] && exit 0 || exit 1
