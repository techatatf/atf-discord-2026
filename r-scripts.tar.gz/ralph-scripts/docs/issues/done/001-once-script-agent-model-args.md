## What to build

Update `once.sh` to accept two positional args: `<agent>` and `<model-alias>`.

Invocation: `./once.sh <agent> <model-alias>`

Agents: `pi`, `claude`

Model aliases:
- `opus` → pi: `anthropic/claude-opus-4.6` / claude: `claude-opus-4-6`
- `kimi` → pi: `openrouter/kimi-k2.6` + `--thinking high` (pi only, error if used with claude)

Agent-specific flags:
- `pi`: `--skill ~/.agents/skills/tdd/SKILL.md`
- `claude`: `--permission-mode acceptEdits`

Show a short usage message if args are missing. Error clearly if an alias isn't valid for the chosen agent. Structure the alias lookup so adding new models in the future is obvious (just add a case).

## Acceptance criteria

- [ ] `./once.sh pi opus` invokes pi with `anthropic/claude-opus-4.6` and `--skill`
- [ ] `./once.sh pi kimi` invokes pi with `openrouter/kimi-k2.6`, `--thinking high`, and `--skill`
- [ ] `./once.sh claude opus` invokes claude with `claude-opus-4-6` and `--permission-mode acceptEdits`
- [ ] `./once.sh claude kimi` errors with a clear message
- [ ] `./once.sh` with no args or one arg shows usage
- [ ] Adding a new model alias requires adding one block/case

## Blocked by

None - can start immediately
